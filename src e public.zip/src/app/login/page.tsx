export default function Login(){
    return (
        <>
        <h1>Logado</h1>
        </>
    )
}